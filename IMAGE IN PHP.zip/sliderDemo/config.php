<?php
$servername="localhost";
$username="root";
$password="";
$dbname="vlog";
$con=new mysqli($servername,$username,$password,$dbname);
if($con->connect_error)
{
	die("connection failed:" . $con->error);
}

?>