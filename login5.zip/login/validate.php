<?php

//extract($_GET);

//print_r($_POST);

$username="";
if(isset($_POST['username'])){
	$username=$_POST['username'];
}

$password="";
if(isset($_POST['password'])){
	$password=$_POST['password'];
}
 



if($username=="abc"&&$password=="abc"){
	echo "Logged In";
}
else{
	header("Location: login.php?error=Password Mismatch");
}


?>