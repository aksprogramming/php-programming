<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap slider</title>
  <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
  <script type="text/javascript" src="jquery.min.js"></script>
  <script type="text/javascript" src="bootstrap.min.js"></script>
</head>
<body>
 
  <div class="container">
   <form method="post" action="upload.php" enctype="multipart/form-data">
     <input type="file" name="file">
     <input type="submit" name="but_upload" value="image upload">
   </form>
  <br>
  <?php 
  include("config.php");
  $sql="select * from image_table";
  ?>
    <h3>bootstrap slider </h3>
    <div id="mySlider" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
         <?php
        $result=mysqli_query($con,$sql);
        foreach ($result as $key => $value) {
          

        ?>
        <li data-target="#mySlider" data-slide-to="<?php echo $key;?>" class=" <?php echo $key==0?"active" :""; ?>"></li>
   
        <?php 
          }
         ?>
      </ol>
      <div class="carousel-inner">
        <?php
        $result=mysqli_query($con,$sql);
        foreach ($result as $key => $value) {
          $image_src=$value['image'];

        ?>
       <div class="item <?php echo $key==0?"active" :""; ?>">
          <img src="<?php echo $image_src; ?>"  style="width:100%">
        </div>
         <?php 
          }
         ?>
         
    </div>
    <a class="left carousel-control" href="#mySlider" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#mySlider" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</body>
</html>
