<?php


  function copyTransparent($src, $output)
    {
        $dimensions = getimagesize($src);
        $x = $dimensions[0];
        $y = $dimensions[1];
        $im = imagecreatetruecolor($x,$y); 
        $src_ = imagecreatefrompng($src); 
        // Prepare alpha channel for transparent background
        $alpha_channel = imagecolorallocatealpha($im, 0, 0, 0, 127); 
        imagecolortransparent($im, $alpha_channel); 
        // Fill image
        imagefill($im, 0, 0, $alpha_channel); 
        // Copy from other
        imagecopy($im,$src_, 0, 0, 0, 0, $x, $y); 
        // Save transparency
        imagesavealpha($im,true); 
        // Save PNG
        imagepng($im,$output,9); 
        imagedestroy($im); 
    }

header('Content-type: image/jpg; charset=utf-8');
$content="aks";
$logo = "Capture.PNG";
// $QR = imagecreatefrompng('https://chart.googleapis.com/chart?cht=qr&chld=H|1&chs=400x400&chl=aksprogramming');


// if($logo !== FALSE){
//     $logo = imagecreatefromstring(file_get_contents($logo));
//     $QR_width = imagesx($QR);
//     $QR_height = imagesy($QR);
    
//     $logo_width = imagesx($logo);
//     $logo_height = imagesy($logo);
    
//     // Scale logo to fit in the QR Code
//     $logo_qr_width = $QR_width/3;
//     $scale = $logo_width/$logo_qr_width;
//     $logo_qr_height = $logo_height/$scale;
    
//     imagecopyresampled($QR, $logo, $QR_width/3, $QR_height/3, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height);
// }

// imagepng($QR);
// imagedestroy($QR);

    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';

    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    
    $filename = $PNG_TEMP_DIR.'test.png';
    $errorCorrectionLevel = 'H';
   

    $matrixPointSize = 13;


	QRcode::png($content, $filename, $errorCorrectionLevel, $matrixPointSize, 2); 
	copyTransparent($filename,$filename); 
	 
	$QR=imagecreatefrompng( $filename);

	if($logo !== FALSE){
	    $logo = imagecreatefromstring(file_get_contents($logo));
	    $QR_width = imagesx($QR);
	    $QR_height = imagesy($QR);
	    
	    $logo_width = imagesx($logo);
	    $logo_height = imagesy($logo);
	    
	    // Scale logo to fit in the QR Code
	    $logo_qr_width = $QR_width/3;
	    $scale = $logo_width/$logo_qr_width;
	    $logo_qr_height = $logo_height/$scale;
	    
	    imagecopyresampled($QR, $logo, $QR_width/3, $QR_height/3, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height);
	}

	imagepng($QR);		
	imagedestroy($QR);	

?>

